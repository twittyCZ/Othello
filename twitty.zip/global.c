#include <stdio.h>
#include "global.h"
struct player* player1 = NULL;
struct player* player2 = NULL;
struct logger* logger = NULL;
struct board* playboard = NULL;

